package com.example.proye_app.host;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
